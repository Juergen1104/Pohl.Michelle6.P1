package p1.exception;

public class IllegalSongException extends Exception {
    public IllegalSongException(String message) {
        super(message);
    }
}